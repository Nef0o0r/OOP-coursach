﻿namespace SeaPort
{
    public enum CargoType
    {
        Bulk, //Сыпучие
        Liquid, //Жидкие
        Container //Контейнеры
    }
}