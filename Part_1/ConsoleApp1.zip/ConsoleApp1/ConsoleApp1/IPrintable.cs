﻿namespace TourSales
{
    internal interface IPrintable
    {
        void Print();
    }
}


